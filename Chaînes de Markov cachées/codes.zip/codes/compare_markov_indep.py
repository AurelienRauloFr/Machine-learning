import numpy as np
from tools import bruit_gauss, calc_erreur
from gaussian_mixture import *
from markov_chain import *

